"""Capture the pre-redesign state before replacing its implementation."""
import asyncio
import hashlib
import json
import platform
import re
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs' / 'implementation'
OUT.mkdir(parents=True, exist_ok=True)
plan = ROOT / 'study' / '简历五条' / '00-RunAgent完整改进执行计划.md'
content = plan.read_text(encoding='utf-8')


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True, encoding='utf-8').strip()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


save('requirements.json', {
    'plan': str(plan.relative_to(ROOT)),
    'plan_sha256': hashlib.sha256(plan.read_bytes()).hexdigest(),
    'tasks': [dict(id=code, requirement=text, status='pending', evidence=[])
              for code, text in re.findall(r'^- \[ \] (P\d-\d+) (.+)$', content, re.M)],
    'acceptance': [dict(id=code, scenario=scenario.strip(), invariant=invariant.strip(),
                        status='pending', evidence=[])
                   for code, scenario, invariant in re.findall(
                       r'^\| ([AGSEV]\d\d) \|([^|]+)\|([^|]+)\|$', content, re.M)],
})
save('baseline-state.json', {
    'commit': git('rev-parse', 'HEAD'),
    'branch': git('branch', '--show-current'),
    'preexisting_changes': git('status', '--short', '--untracked-files=no').splitlines(),
    'references': {name: git('rev-parse', 'HEAD', cwd=ROOT.parent / name)
                   for name in ['pi', 'hermes-agent']},
    'platform': platform.platform(),
    'python': platform.python_version(),
    'scope': 'Single Windows host; synthetic baseline, no model capability claims.',
})


async def main():
    from run_agent_core.messages import UserMessage
    from run_agent_core.session import JsonlSessionStorage, MessageEntry
    from run_agent_evals.runtime_bench import RuntimeBenchmarkConfig, run_runtime_benchmarks

    report = await run_runtime_benchmarks(ROOT / '.run/redesign/baseline-runtime',
        RuntimeBenchmarkConfig(scheduler_requests=10_000, scheduler_sessions=100,
                               tool_repeats=3, trace_repeats=3))
    save('baseline-runtime.json', {
        'source_commit': git('rev-parse', 'HEAD'),
        'workload': 'Existing runtime_bench: synthetic runner with sleep(0); no LLM.',
        'summary': report.summary,
        'manifest_digest': report.manifest_digest,
        'inventory_digest': report.inventory_digest,
        'report_digest': report.report_digest,
    })
    for name in ['manifest.json', 'samples.json', 'inventory.json', 'report.json']:
        target = OUT / 'baseline-runtime'
        target.mkdir(exist_ok=True)
        (target / name).write_bytes((report.root / name).read_bytes())

    samples = []
    with tempfile.TemporaryDirectory(prefix='run-storage-baseline-') as directory:
        for size in [1000, 10_000, 100_000]:
            storage = JsonlSessionStorage(Path(directory) / f'{size}.jsonl')
            entries = [MessageEntry(id=f'entry-{i}', parent_id=f'entry-{i-1}' if i else None,
                       message=UserMessage(content='Repository task evidence. ' * 12))
                       for i in range(size)]
            start = time.perf_counter()
            await storage.append_batch(entries)
            populate = (time.perf_counter() - start) * 1000
            timings = []
            for i in range(3):
                entry = MessageEntry(id=f'entry-{size+i}', parent_id=f'entry-{size+i-1}',
                                     message=UserMessage(content='Follow-up evidence.'))
                start = time.perf_counter()
                await storage.append(entry)
                timings.append((time.perf_counter() - start) * 1000)
            start = time.perf_counter()
            loaded = await storage.read_all()
            read_ms = (time.perf_counter() - start) * 1000
            assert len(loaded) == size + 3
            samples.append(dict(entries=size, populate_ms=populate, append_ms=timings,
                                warm_read_ms=read_ms, bytes=storage.path.stat().st_size))
    save('baseline-storage.json', {
        'source_commit': git('rev-parse', 'HEAD'), 'samples': samples,
        'conditions': 'Single process; fsync on every append; sequential parent chain; '
                      'batch populate, 3 append samples, warm read; Windows local filesystem. '
                      'No claim about cold cache, branches or model performance.',
    })
    print('Captured requirements, original state, 10,000-request runtime and storage baselines.')


asyncio.run(main())
